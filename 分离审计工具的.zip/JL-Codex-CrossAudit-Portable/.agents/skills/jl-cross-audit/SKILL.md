---
name: jl-cross-audit
description: Run an evidence-grounded cross-model AI system-change audit for JL Insurance using the company background and the user-uploaded CEO brief. Performs blind Codex assessment, independent Qwen and DeepSeek review through the minimal API bridge, evidence adjudication, and final audit reporting. Use whenever a new CEO system-change brief is provided or a JL AI change audit is requested.
---

# JL cross-audit skill

Read in this order:
1. Root `AGENTS.md` and `jl_insurance_background.md`.
2. Project-root `AI_AUDIT_PROMPT.md` in full, before any audit analysis (authoritative configurable professional criteria; not case evidence). If missing or unreadable, report the blocker.
3. `CROSS_AUDIT_WORKFLOW.md`.
4. `audit_report_template.md` before rendering the final report.

**Important:** The CEO brief is received in the current Codex App chat; there is no `cases/` directory. Use the actual current user-supplied content. A file in chat is not necessarily mounted as a local file: confirm accessibility; never invent extracted text.

## Fixed sequence (do not skip silently)
1. **Intake and boundary:** identify current CEO brief, any supplements, file readability and scope. Number source excerpts `BG-01`, `CEO-01`, etc. Preserve exact quotes. Separate current facts from management claims and unknowns.
2. **Blind Codex review:** analyze change against JL's known current pilot; draft change profile and a *provisional* findings list by applying `AI_AUDIT_PROMPT.md`. Do not view external opinions yet.
3. **Two external blind reviews:** with explicit permission for external transfer and working local API bridge, send identical primary source material to Qwen and DeepSeek concurrently. They may have different audit lenses but **must not receive Codex findings or each other's opinions**. Invoke `run_bridge.cmd` from the project root using the validated JSON packet on standard input; the launcher must use the bundled `runtime\python.exe`. Do not fall back to system Python or `.venv`. Do not run this step if user data is not permitted to be transmitted.
4. **Source-based adjudication:** align duplicate findings; for each external claim look up the quoted primary passage and note whether it actually supports the conclusion. Consider counter-evidence and supported minority findings; apply the control, classification and rating criteria in `AI_AUDIT_PROMPT.md`. Mark `accepted`, `qualified`, `rejected`, or `unresolved`; record why and by which source.
5. **Challenge once:** apply the critical-challenge and recommendation criteria in `AI_AUDIT_PROMPT.md`. Repair your analysis.
6. **Final report:** use `audit_report_template.md`. If any external provider was skipped/failed, explicitly identify it and avoid statements about independent consensus. Apply `AI_AUDIT_PROMPT.md` and record the actual loaded prompt version in execution verification.

7. **PDF delivery:** after the final report is settled, use available Codex PDF capabilities or local tools to export the same complete report to the authorized project-root `reports/` directory, with a unique audit identifier and timestamp. Follow the PDF delivery rules in `AGENTS.md` and `CROSS_AUDIT_WORKFLOW.md`. Verify the file and its content/layout to the extent possible; provide its actual path alongside the full conversation report. Do not re-audit, overwrite prior reports, or use external conversion services.

## Failure behavior
- If no readable CEO brief: do not pretend to audit; explain what input is missing.
- If no external API/network/permission: still perform Codex-only assessment, mark external review unavailable, and do not claim bias mitigation from cross-model results.
- If an API returns malformed JSON or a quote mismatch: treat that model claim as unverified; retain a review log entry, not an audit fact.
- If material evidence conflicts: keep the conflict visible and propose an appropriate verification step, not an invented resolution.
- Do not perform unlimited loops or re-consult repeatedly to force agreement.
- If PDF generation is unavailable or fails, disclose the reason and retain the complete conversation report; never claim an uncreated PDF exists.

The user may request a concise or full report; preserve the same evidence rigor either way.
