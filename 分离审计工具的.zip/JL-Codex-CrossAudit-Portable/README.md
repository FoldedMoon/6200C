# JL Insurance Cross-Audit Harness｜中文使用说明

## 1. 项目用途

本项目是 ISOM6200C 小组作业中用于 **JL Insurance Limited（虚构保险公司）AI 系统变更审计**的可迁移审计工作环境。

使用者在 **Codex App** 中打开本项目，上传本次 CEO System-Change Brief，再发送配套审计提示词。Codex 负责主审计、证据核验和最终报告；Qwen 与 DeepSeek 分别提供独立复核意见。审计结论是供内部审计人员判断的**决策支持**，不是自动批准、合规认证或真实系统的控制有效性保证。

本项目不需要单独部署网站、服务器、数据库或图形界面。运行所需 Python 已随项目打包；**目标 Windows 电脑通常不需要另外安装 Python、建立虚拟环境或配置 PATH**。

## 2. 架构概览

```text
Codex App（Local 模式，打开本项目）
│
├─ 读取固定背景：jl_insurance_background.md
├─ 读取本次聊天上传的 CEO Brief（PDF / DOCX / TXT / 图片等）
├─ 按 AGENTS.md、SKILL.md、CROSS_AUDIT_WORKFLOW.md 执行
├─ 读取 AI_AUDIT_PROMPT.md（Evaluation 组维护的专业审计提示词）
├─ 先独立形成 Codex 初步审计意见
│
└─ 调用 run_bridge.cmd
   └─ runtime/python.exe（项目内置 Portable Python）
      └─ tools/consult_models.py
         ├─ Qwen：独立风险发现与补充视角
         └─ DeepSeek：独立质疑与反证视角
              ↓
Codex 汇总、核对原始证据、裁定分歧
              ↓
依照 audit_report_template.md 形成同一份最终报告
              ├─ Codex 对话完整输出
              └─ Codex 使用可用 PDF 工具在本地导出 reports/*.pdf
```

**关键原则：** Codex 是主审计员和最终裁定者；两位外部审查员的意见仅供参考，不能替代 CEO Brief 和固定公司背景等一手证据；不以模型投票决定结论。

## 3. 文件与目录说明

以下按当前便携版 ZIP 的实际结构及本次新增的 README、PDF 输出目录列出：

```text
JL-Codex-CrossAudit-Portable/
├── .agents/
│   └── skills/
│       └── jl-cross-audit/
│           └── SKILL.md
├── runtime/                       # 内置 Windows x64 Python 3.13 运行时
├── tools/
│   └── consult_models.py          # 双模型独立复核桥接脚本
├── AGENTS.md                      # Codex 项目级角色、约束和证据规则
├── AI_AUDIT_PROMPT.md             # 专业审计提示词（Evaluation 组维护）
├── CROSS_AUDIT_WORKFLOW.md        # 审计步骤与执行标准
├── audit_report_template.md       # 最终报告模板
├── jl_insurance_background.md     # JL Insurance 固定背景
├── run_bridge.cmd                 # 使用内置 Python 的启动器
├── JL_Cross_Audit_Run_Prompt_portable.txt  # 完整审计指令（上传至对话）
├── 新的短prompt, 需要复制其中的内容.txt   # 短启动指令（复制至输入框）
├── README.md                      # 本使用说明
└── reports/                       # PDF 导出时自动创建
```

文件作用简述：

| 文件 | 作用 |
| --- | --- |
| `AGENTS.md` | 规定 Codex 的审计角色、权限、安全与证据边界和输出要求。 |
| `AI_AUDIT_PROMPT.md` | 集中维护 Codex 的专业审计判断标准，包括风险领域、控制判断、发现分类、风险评级和复核建议。 |
| `.agents/skills/jl-cross-audit/SKILL.md` | 使 `$jl-cross-audit` 对应完整的审计技能与执行顺序。 |
| `CROSS_AUDIT_WORKFLOW.md` | 定义文件读取、独立初审、双模型复核、分歧裁定和报告生成流程。 |
| `jl_insurance_background.md` | 固定公司背景；每次审计均与新 CEO Brief 比较。 |
| `audit_report_template.md` | 约束最终报告的结构和必要信息。 |
| `run_bridge.cmd` | 从项目自身目录启动 `runtime\python.exe`，无需查找系统 Python。 |
| `runtime/` | 随项目携带的 Python 解释器及标准库；整个目录必须保留。 |
| `tools/consult_models.py` | 向两位独立复核员提交相同的材料并返回审查意见。 |
| `JL_Cross_Audit_Run_Prompt_portable.txt` | 用户每次开始审计时上传到 Codex 对话中的完整指令。 |
| `新的短prompt, 需要复制其中的内容.txt` | 与长 Prompt 一起使用：复制其全部内容到 Codex 输入框并发送。 |

**注意：** `.agents` 是以句点开头的目录；解压和复制时必须保留它及完整子目录。案例文件由用户在**当前 Codex 对话**上传，不需要创建 `cases/` 文件夹，也不应直接修改固定公司背景。

## 4. 首次部署（新电脑）

### 4.1 所需条件

- 一台兼容的 **Windows x64** 电脑。
- 已安装并能够使用 **Codex App**；使用可以打开本地项目文件夹的 **Local 模式**。
- 最新版 `JL-Codex-CrossAudit-Portable` 文件夹及配套 Prompt TXT。
- 审计过程中如 Codex 请求执行命令或访问网络，请按实际请求范围在应用中审批；建议使用 **「帮我批准」（Ask for approval）** 权限等级。

### 4.2 解压和打开项目

1. 把便携版 ZIP 解压到任意有读写权限的位置，例如桌面或 `D:\Projects\`。
2. 确认项目根目录中**直接**存在 `AGENTS.md`、`AI_AUDIT_PROMPT.md`、`run_bridge.cmd`、`runtime`、`tools`、`.agents`。不要把 Codex 打开在它们的上一级目录。
3. 打开 Codex App，选择 **Local**，将工作目录设置为 `JL-Codex-CrossAudit-Portable` 项目根目录。
4. 使用一个新的 Codex 对话执行一次新案例，避免混用过去审计的附件或结论。

### 4.3 可选的本地运行时检查

如果想确认项目自带 Python 可执行，在项目根目录的 Windows PowerShell 运行：

```powershell
.\runtime\python.exe --version
```

应显示 Python 3.13.x。该命令只检查本地运行时，不会开始审计。

**无需**安装系统 Python、运行 `pip install`、创建 `.venv`，或更改 Windows 环境变量。

## 5. 每次审计的详细操作

### 第一步：准备本次 CEO Brief

获取教师或演示提供的 CEO System-Change Brief。可以使用 Codex 可读取的 DOCX、PDF、TXT 或图片格式；扫描件应注意文字识别质量。

只把**本次**案例作为当前审计的依据。不要把历史 CEO Brief、旧的审计报告或其他案例放入固定背景文件。

### 第二步：在 Codex App 打开项目

1. 确认当前工作区是 `JL-Codex-CrossAudit-Portable` 项目根目录。
2. 采用 **Local** 模式，并维持 **「帮我批准」（Ask for approval）**。
3. 建议为每份独立的 CEO Brief 新建对话，避免前一个案例的内容污染当前分析。

### 第三步：上传文件

在**当前 Codex 对话**中上传 CEO Brief。可以同时上传明确属于本案例的补充材料，但不要把 `JL_Cross_Audit_Run_Prompt_portable.txt` 误当作 CEO Brief。

上传文件不代表命令行工具一定能直接访问附件路径。Codex 应首先检查附件是否可读、提取实际内容，并保留重要的数字、日期、否定词、表格与来源位置。若有内容不可读，应在报告中说明。

### 第四步：发送审计提示词

在上传 CEO Brief 的同一个 Codex 对话中，上传 `JL_Cross_Audit_Run_Prompt_portable.txt`。打开 `新的短prompt, 需要复制其中的内容.txt`，**复制其全部内容到输入框并发送**。短指令以 `$jl-cross-audit` 开头，明确要求读取长 Prompt、项目 Skill 和 `AI_AUDIT_PROMPT.md`，并区分执行指令与 CEO Brief 证据。

不要只发送 “analyze this” 或 “follow the prompt”。如果长 Prompt 无法作为附件读取，可直接粘贴其完整内容并确认 Codex 可读。

### 第五步：处理审批请求

审计过程中 Codex 可能请求执行项目中的 `run_bridge.cmd`，也可能在默认沙箱阻止外部复核连接时提出额外权限请求。

- 检查待执行命令是否与本项目审计有关。
- 如属预期操作，可在 **「帮我批准」** 界面批准该次请求。
- 不需要为了运行本项目改用 Full Access。
- 如果你拒绝了必要权限，Codex 应如实说明无法完成的步骤，而不能伪造复核结果。

### 第六步：读取结果

正常情况下，Codex 会依次完成：

1. **材料读取：** 读取固定背景和本次 CEO Brief，并说明实际读取范围。
2. **独立初审：** 在看到外部复核意见前形成 Codex 初步风险与控制判断。
3. **双模型复核：** Qwen 和 DeepSeek 分别基于同一批原始资料独立审查。
4. **证据裁定：** 比较三方观点，核对原文、识别有效分歧，修正夸大或缺乏证据的结论。
5. **报告生成：** 在 Codex 对话中输出最终 AI System-Change Audit Report，并使用可用的本地 PDF 工具导出同一份报告。

最终报告应涵盖：执行摘要、系统变更概况、优先级审计发现、控制评价、信息缺口、实际可行的建议、跨模型分歧与裁定、审计局限以及需要人工确认的事项。

### 第七步：获取 PDF 报告（本次升级新增）

新版 Prompt 要求 Codex 在完成原有审计之后，使用当前环境可用的 PDF Skill 或本地 PDF 工具，将同一份完整最终报告导出为 PDF，同时保留对话中的完整报告。不需要另外编写导出脚本或修改通信桥。

1. 如 Codex 请求本地文件创建或 PDF 工具执行权限，检查请求范围并按需审批。
2. 查看 Codex 给出的实际 PDF 路径，并在项目根目录的 `reports/` 中打开文件。文件名包含本次审计标识及时间戳，以避免覆盖旧报告。
3. 核对 PDF 中的完整发现、风险等级、原文引用、交叉审计矩阵和执行验证，与对话报告保持一致。检查分页、表格和文字是否清晰。
4. 若当前 Codex 环境没有可用 PDF 生成能力，或导出失败，Codex 必须说明原因并仍然输出完整对话报告。不要仅为导出重新执行三模型审计，也不要将报告上传到第三方转换网站。

`reports/` 是获授权的本地交付目录，不属于永久案例知识库。不同电脑的 PDF 工具可用性可能不同；内置 Python 并不自动提供 PDF 排版能力。

### 第八步：保留正式输出

对于课程正式现场评估，请保存**首次完成的最终报告**作为原始现场报告。之后的补充分析或文字修改应单独保存并标记为修订版，不能用后来版本覆盖原始输出。

建议同时保留本次使用的 CEO Brief、Codex 对话记录以及最终报告，便于小组其他成员进行质量评价和书面报告撰写。模拟练习应标记为 `SIMULATION / PRACTICE AUDIT`，不能冒充正式现场评估。

## 6. 常见问题与处理

| 现象 | 可能原因与处理方式 |
| --- | --- |
| Codex 没有调用 `$jl-cross-audit` | 确认打开的是项目根目录，`.agents/skills/jl-cross-audit/SKILL.md` 存在，并上传长 Prompt、发送短启动指令。 |
| Codex 找不到 `run_bridge.cmd` | 确认当前工作区为项目根目录，启动器与 `AGENTS.md` 同级。 |
| 提示找不到 Python | 检查 `runtime/python.exe` 是否存在，以及 `runtime/` 是否完整解压；本项目不应依赖系统 Python。 |
| 上传的 PDF / DOCX 无法正确读取 | 换用更清晰的文件、提取可读文字后再次上传；不得用猜测填补未读内容。 |
| 沙箱阻止某一步骤 | 查看 Codex 的具体审批请求，并按本次任务需要决定是否批准。 |
| 外部复核未完成 | 报告应将其明确标为未完成或降级审计，不得声称获得三模型一致结论。 |
| 输出引用与原文不一致 | 以 CEO Brief 和固定背景为准；要求 Codex重新核对引文和语义，不得把模型陈述当成公司事实。 |
| PDF 未生成或排版异常 | 查看 Codex 披露的工具或权限限制；保留完整对话报告。可要求仅重新导出同一份已定稿报告，不重复外部复核。 |
| 报告出现其他案例的内容 | 新建对话，确认只上传当前 CEO Brief，并上传长 Prompt、发送短启动指令。 |
| 找不到 `AI_AUDIT_PROMPT.md` | 确认该文件在项目根目录且可读；不应静默跳过专业审计标准。 |

## 7. 使用边界与注意事项

- 本系统审阅的是**拟议的 AI 系统变更**，不是直接操作 JL 的真实保单、客户或理赔系统。
- 不应把“文件没有提到某项控制”自动等同于“控制不存在”；拟议的保障措施也不等于已实施或有效。
- 所有重要结论必须能回到当前 CEO Brief 或固定背景中的证据；外部复核的观点只能作为待验证的分析线索。
- 审计报告属于**决策支持材料**。最终风险接受、上线决定、整改与签字由人类管理人员及内部审计人员负责。
- 不要修改 `AGENTS.md`、`SKILL.md`、`CROSS_AUDIT_WORKFLOW.md` 或固定背景来迎合某个案例；它们是可复用的项目规则。审计运行时也不得自行修改 `AI_AUDIT_PROMPT.md`；Evaluation 组应在独立的优化与测试阶段更新它。

## 8. Evaluation 组：专业审计提示词维护

- `AI_AUDIT_PROMPT.md` 是唯一日常维护的 Codex 专业审计提示词文件。初版由原有审计规则提取而来，不新增监管要求。可优化风险关注重点、证据与控制判断、发现分类判断、评级依据及整改建议。
- 每次评估先保留基线提示词版本和实际结果，再单独更新此文件及其 Version，使用相同的模拟 CEO Brief、相同运行配置在新对话中复测；人工比较风险遗漏、误报、引用错误及评级偏差，并对既有测试案例进行回归检查。使用 GitHub Commit History 记录修改及回退。
- 保持报告字段、分类标签、运行权限、证据边界及原工作流不变；这些不是日常提示词优化范围。若需改变报告接口或外部模型提示词，则属于另一次独立变更。
- Qwen 和 DeepSeek 继续使用 Bridge 内原有的独立审查指令，不读取新文件。每次报告的执行验证应记录实际加载的审计提示词版本。不要把模型一致意见当作评估真值。
- 不需要修改 AGENTS.md、Workflow、Skill 或两个启动 Prompt 来同步普通专业判断标准的调整。不增加模型调用、第三方依赖或新的执行阶段。LLM 结果及用时仍可能波动，需通过实际对照测试确认。

---

**最简操作流程：** 解压项目 → Codex App 选择 Local 并打开项目根目录 → 新对话上传 CEO Brief 和 `JL_Cross_Audit_Run_Prompt_portable.txt` → 复制粘贴短启动指令 → 按需审批 → 查看完整审计报告及 `reports/` 中的 PDF（若导出成功）。
