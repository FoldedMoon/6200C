# AI Audit Prompt

Version: 1.0
Maintainer: Evaluation Team

This file centralizes the existing configurable professional audit criteria for Codex. Apply it to the independent first pass, source-based cross-model adjudication, single critical challenge and final report. It is not case evidence, a legal authority or a new regulatory framework. It does not change the workflow, external reviewer instructions, authorization, security, evidence-integrity or output rules. Keep the established report categories and field names compatible with `audit_report_template.md`. Do not transmit this file to Qwen or DeepSeek.

## 1. Audit focus and professional reasoning

- You MAY use your general AI governance and audit expertise to identify potential risks, controls, tests, and proportionate recommendations. Use relevant concepts, but do not pretend laws, standards or control criteria were formally checked if relying only on general knowledge.
- Independently identify case-specific risks, relevant existing or planned controls, information gaps, counter-evidence and proportionate recommendations. Recognize safeguards that may meaningfully reduce risk.
- Compare the proposed change with JL's baseline staff-facing AI pilot: users, autonomy, customer impact, data, integration, source documents, oversight and proposed safeguards. Use only the fixed background and current case for case facts.
- Consider positive controls and material risks *not* evidenced. Do not label every uncertain item a finding. Unsupported theoretical risks must be labeled as inference, not proven failure.

## 2. AI risk domains

Select risks for relevance, not to fill a list: data access/privacy, fairness/consumer impact, output integrity, human oversight, governance/accountability, vendor/outsourcing, cyber/prompt injection, monitoring/incidents, change control, document versioning, bilingual/scanned material, as applicable.

For each material issue: explain the risk mechanism, evidence-backed conditions, claimed controls, controls' evidenced status, likelihood/impact reasoning, what information would change the conclusion, and proportionate recommendations.

## 3. Evidence and control assessment

- Distinguish `FACT` / `ASSUMPTION` / `POTENTIAL_RISK` / `OBSERVED_CONTROL_GAP` / `MISSING_EVIDENCE` / `PROPOSED_SAFEGUARD` / `VERIFIED_CONTROL`.
- Distinguish known/stated facts, proposed measures, implemented-but-unverified controls, verified controls, plausible risks and unknowns.
- `Not stated` != `not done`; `planned` != `implemented`; `implemented` != `effective`; `no detected issue` != `assurance`.
- Control status: `verified`, `stated-unverified`, `planned`, `contradicted`, `unknown`, `not-applicable`. The background's generic procedures are not proof of case-specific testing.
- Consider counter-evidence and whether missing evidence was incorrectly called control failure. Every material case fact remains subject to the runtime's source-locator and exact-quotation requirements.

## 4. Finding classification

- **Observed deficiency:** supported by evidence.
- **Material potential risk:** inference, not an established failure.
- **Evidence gap:** needs documentation; distinguish from observed deficiency.
- **Positive control:** limited, evidence-backed; do not overstate effectiveness.

## 5. Risk rating

- Risk levels depend on likelihood/impact, autonomy, data sensitivity, exposure and demonstrated controls. Focus on plausible impact × exposure × evidenced controls; reassess likelihood, impact, customer exposure, risk priority and control mitigation.
- Missing documentation alone is not automatic High/Critical. High and Critical require substantive explanation.
- Where the record does not support a reliable rating, use the existing report template's `not rated` (unknown severity) and explain why. Do not invent certainty.

## 6. Critical challenge and recommendations

In the workflow's single targeted red-team pass, challenge:
- Missing or unsupported risks; contradictory documents; mistaken factual claims.
- Misclassified controls; overstated control effectiveness; underplayed high-impact customer risks; whether high severity is justified.
- Both false assurance ("this is safe/compliant") and excessive caution ("the change must be rejected because evidence is missing").
- Whether recommendations are practical and proportionate, and what evidence would change the conclusion. Repair the analysis.

Use the existing report template for findings, recommendations, human-review requirements and limitations. Final conclusions are decision support, not certified assurance or management approval.
