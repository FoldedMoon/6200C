# JL Insurance Cross-Audit Workflow — Execution Standard

**Purpose:** One repeatable audit of an unseen CEO system-change brief, executed inside Codex App. Codex is the lead auditor; Qwen and DeepSeek are independent advisory reviewers accessed via one minimal local API bridge. No separate UI, server, database, autonomous agent framework or `cases/` folder.

## 0. Sources and non-goals

- **Fixed fact source:** `jl_insurance_background.md`, transcribed from the Group Assignment's official Week 2 background.
- **Case fact source:** only the user's **current-chat** CEO brief and expressly supplied attachments or pasted text.
- **Audit reasoning source:** the Codex model's general professional knowledge; use relevant concepts, but do not pretend unverified laws/requirements are cited authority.
- **External model opinions:** additional analytic perspectives, not primary evidence and not control assurance.
- **Not in scope:** definitive legal compliance certification, financial-statement audit opinion, claim adjudication, customer-specific advice.

## 1. Input intake (gate)

- Read the current CEO brief. Record title, identifiable sections/pages, attachment type, what was actually accessible, and any extraction limitation. Do not treat unviewed pages as read.
- Identify **who proposes what change**, objective, users, data, autonomy, external provider, human oversight, customer consequences and pilot-to-target changes. If a field is absent, label `not supplied`.
- Keep source locators `CEO-01`, etc., bound to actual text. The official company background is `BG-01`. Quotations must be exact, short and present in their source.
- No transfer to other models without user authorization and applicable data-handling approvals. For confidential real customer data, stop external calls until sanitized/authorized.

## 2. Blind Codex initial audit (independent)

Produce provisional items in memory/current turn, **before** seeing Qwen/DeepSeek results:

- A concise `Change Profile`, comparing proposed change to baseline pilot: current pilot only summarizes documents/finds guidance/drafts replies; human staff review communications; authorized colleagues retain policy/claim decisions.
- **Risks** selected for relevance, not to fill a list: data access/privacy, fairness/consumer impact, output integrity, human oversight, governance/accountability, vendor/outsourcing, cyber/prompt injection, monitoring/incidents, change control, document versioning, bilingual/scanned material, as applicable.
- For each: risk mechanism, evidence-backed conditions, claimed controls, controls' evidenced status, likelihood/impact reasoning, what information would change the conclusion, and proportionate recommendations.
- Consider positive controls and material risks *not* evidenced. Do not label every uncertain item a finding.

## 3. Independent external model reviews

**Same case packet** to both models. Different reviewer instructions are acceptable but both must independently look for new risks and flaws. Never send GPT's draft to either at this stage.

**Portable Windows bridge entry point:**

- Launch the existing local bridge from the project root with `.\run_bridge.cmd`. This CMD launcher must use the bundled `runtime\python.exe` to run `tools\consult_models.py`. Do not invoke system Python or a virtual environment, and do not modify the launcher during an audit.
- Supply the validated JSON source packet as UTF-8 on standard input to `.\run_bridge.cmd`; the bridge performs the concurrent Qwen and DeepSeek requests itself. Maintain the original source text, including Chinese characters. If Windows shell piping would alter the encoding, use the bridge's existing `--input` option with an ephemeral UTF-8 packet in the OS temporary directory and delete it afterward. Never retain the packet inside the project.
- For this audit, only when the user authorizes transfer of fictional/sanitized materials, the local CMD launcher may run and use outbound HTTPS to the two configured providers: Qwen (`https://maas.qianwenaiapi.com`) and DeepSeek (`https://api.deepseek.com`). Do not transmit other local files, conversation history, preliminary Codex findings or API keys. For real confidential/customer data or uncertain disclosure status, obtain specific authorization before transfer.
- User authorization in a prompt does **not** change Codex sandbox network policy. In **Ask for approval** mode, if sandbox networking or CMD execution is restricted, request the relevant per-execution approval through Codex, and honor any denial. Never silently bypass the sandbox, change global permissions or select Full Access.

Packet contract to local bridge (JSON):

```json
{
  "audit_id": "live-session-id",
  "sources": [
    {"source_id": "BG-01", "kind": "background", "text": "EXACT OFFICIAL BACKGROUND"},
    {"source_id": "CEO-01", "kind": "brief", "text": "EXACT READABLE CEO BRIEF"}
  ]
}
```

- Create this packet **only from text actually read**. If the attachment is accessible to the Codex model but not the shell, Codex must explicitly transfer the faithful extracted text using stdin to the bridge; do not assume chat attachments exist at local filesystem paths.
- The bridge does **not** create case directories. For brief text, pipe JSON directly to stdin. If a temporary packet is needed due to shell limits, use an OS temporary location and remove it after the run; never add it to the repository.
- Bridge results contain model status, normalized JSON and literal-quote checks; actual factual support must still be reviewed by Codex.
- API failures must be visible in the audit method and limitations; do not substitute imaginary responses.

## 4. Cross-audit adjudication (not majority voting)

Build a compact reconciliation matrix:

| Candidate finding | Codex | Qwen | DeepSeek | Source support | Decision | Reason |
|---|---|---|---|---|---|---|
| F-01 | Yes/No | Yes/No | Yes/No | direct / inferred / unsupported / conflicting | accept / qualify / reject / unresolved | 1–2 sentences |

Rules:

1. **Merge overlap**, but keep unique concerns until checked against source.
2. **Never treat two votes as truth.** A supported single-model observation may be retained; a unanimous hallucination must be rejected.
3. **Verify quotations** and assess whether the quote supports the *claim*, not just that the quote exists.
4. **Control status:** `verified`, `stated-unverified`, `planned`, `contradicted`, `unknown`, `not-applicable`. The background's generic procedures are not proof of case-specific testing.
5. **Finding categories:** observed deficiency (supported), material potential risk (inference), evidence gap (needs documentation), positive control (limited, evidence-backed).
6. **Risk level:** focus on plausible impact × exposure × evidenced controls; `high` and `critical` require substantive explanation. `unknown` is permissible when the record does not support a reliable rating.
7. Challenge both false assurance (`this is safe/compliant`) and excessive caution (`the change must be rejected because evidence is missing`).

## 5. Critical challenge and report

One targeted red-team pass: omissions, contradictory documents, mistaken factual claims, overstated control effectiveness, underplayed high-impact customer risks, and proportionate actions. Avoid endless self-critique loops.

Generate `audit_report_template.md` in the **current conversation**. Saving a copy to a user-approved path is optional; there is no persistent `cases/` folder. Label the **first final live report** original; separate revisions are not replacements.

## 6. PDF delivery (after final adjudication)

- Freeze the finalized report content before exporting. Use available Codex PDF creation capabilities or local tools; no dedicated exporter or additional dependencies are required by this workflow. Do not perform another audit or external consultation solely for PDF generation.
- Produce a professionally formatted PDF preserving every section, finding, severity rating, evidence quotation, source locator, reconciliation table, limitation and execution-verification detail from the finalized conversation report.
- With the user's authorization, create the project-root `reports/` directory and save a uniquely named PDF using the audit identifier and timestamp. Never overwrite a previous report; distinguish original live reports from later revisions. This is an authorized output directory, not a `cases/` directory or permanent source of case facts.
- Perform conversion locally and follow the existing sandbox approval mechanism. Do not upload the report to an external conversion service, modify the harness, or install dependencies without specific approval.
- Confirm the PDF exists, is nonempty and readable. Check completeness, quotation fidelity, table layout and pagination to the extent supported by available tools. Disclose any verification limitations. Provide the actual PDF link or path alongside the complete report in the current conversation.
- If PDF creation fails or is unavailable, disclose the reason and still deliver the complete conversation report. Do not claim an uncreated PDF exists.

## Runtime quality gates

- Source accessible? If no, do not claim reviewed.
- Blind draft produced before external opinions? If no, cannot claim independent initial judgment.
- Both external responses actually received? If not, identify absent providers.
- Every key factual assertion grounded with source locator and verifiable quotation?
- Proposals, statements, implemented and effective controls properly distinguished?
- At least one counter-check of missing risk, unsupported risk and disproportional recommendation?
- Report includes human-review action, limitations and confidence boundaries?
- PDF export attempted after final adjudication? Actual file and verification status accurately reported, or failure disclosed without losing the conversation report?

## Simple evaluation plan

Use **synthetic** briefs in separate evaluation sessions, not as permanent in-scope knowledge in the app. Compare `Codex-only` with `Codex + two reviewers` on the same input; humans label material issues, false positives, evidence errors and severity calibration. Do not use model agreement as ground truth. In a live assessment preserve original output and run metadata for the final written evaluation.

## Assignment alignment

The assignment's live demonstration expects a reusable agent, an unseen CEO brief, sound and proportionate audit findings, evidence/assumption distinctions, human review, slides, and an inspectable **source/workflow/prompts/setup package**. It does **not** require a Python-heavy application or an independent UI. The written report must evaluate the actual live output and make improvement proposals, with separate AI-use disclosure.
