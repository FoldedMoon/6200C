# JL Insurance Limited — Official Assignment Background

> Source: `ISOM6200C_Assignments.html`, Group Project, “Common company background · Week 2”.
> This file reproduces only the company background. It is **not** a record of controls verified by internal audit.

## Company and customers

JL Insurance Limited is a fictional, medium-sized Hong Kong insurer serving individuals, families and corporate customers. Its products include life and health insurance, savings and retirement plans, and employee benefits. Customers buy through advisers, brokers and employer schemes, then contact JL through its website, service centres, telephone team or their adviser. Some customers prefer digital services; others rely on staff to explain documents or help with a claim.

The company is expanding its employer-benefits business while continuing to serve long-standing individual policyholders. It runs health seminars and adviser events, and is refreshing its customer website. Service volumes rise during annual scheme renewals and after promotional campaigns. Management tracks response times, repeat enquiries, complaints and operating costs alongside sales.

## Daily operations

A customer enquiry may involve policy wording, a benefit schedule, earlier correspondence and information held by another team. Claims staff also work with application forms, invoices, medical documents and supporting explanations. Materials arrive in English and Chinese, as online submissions, email attachments and scanned documents. A corporate benefits enquiry may concern an employer’s scheme and an employee’s individual circumstances.

Policy administration, claims handling and customer correspondence use separate systems. Staff move between these systems as they work on a case. Product teams maintain policy wording and service guidance; operations teams maintain work instructions. A customer’s file can contain documents created at different times, including later amendments. Monthly management reports summarise activity across departments, while supervisors use case-level records to follow up individual matters.

## Current AI pilot

JL is piloting an AI assistant with a small group of customer-service and claims staff. They use it to summarise documents, find passages in selected product guidance and prepare draft responses. Staff review the material before using it in customer communications. Policy and claim decisions remain with authorised colleagues; the pilot does not independently approve, reject or pay claims.

The assistant uses a commercial AI service together with a company-managed collection of reference documents. IT supports the connection and user access; product and operations colleagues supply the reference material. Pilot participants discuss their experience in regular meetings. Feedback includes comments about convenience, the time spent checking drafts and how the assistant handles different document types. The pilot team is collecting this feedback as it considers the next stage.

## Management plans

The CEO wants to explore wider use of AI across the business. Customer service, claims, product development and distribution teams have different ideas about where it could help. Some proposals concern internal work; others could change how information reaches customers or business partners. Management has not selected a single expansion plan.

The Chief AI Officer coordinates these discussions with business sponsors and IT. Compliance advises on company obligations, and internal audit provides independent assurance. JL has existing procedures for service changes, customer information, testing and incident handling; product teams also maintain instructions for their own operations. Executive management has asked the CAIO’s team to develop a reusable AI audit agent for internal audit to use when reviewing proposed changes.
