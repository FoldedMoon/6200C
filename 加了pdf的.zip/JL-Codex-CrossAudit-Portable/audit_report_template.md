# JL Insurance Limited — Independent AI System Change Audit (Decision Support)

**Audit reference:** [ID or session]
**Audited proposal:** [from CEO brief]
**Review basis:** JL background + [current brief/attachments actually read]
**Review method:** Codex blind assessment; Qwen [completed/failed/not authorized]; DeepSeek [completed/failed/not authorized]; source-based adjudication
**Status:** Original live report / later revised report (choose one)

## 1. Executive summary
- **Overall assessment:** [conditional and limited; not a certification]
- **Most consequential risks:** [prioritize; no inflated list]
- **Recommended disposition for human consideration:** [e.g. proceed with specified preconditions / request further evidence / revise scope; do not present model advice as final approval]

## 2. Change profile and audit scope
| Aspect | Before (JL baseline) | Proposed change | Source / uncertainty |
|---|---|---|---|
| Use case | | | |
| Autonomy / human oversight | | | |
| Data and customers | | | |
| Technology / vendor | | | |

**Readability/coverage limitations:** [exactly what was not readable or not provided]

## 3. Prioritized audit findings
Repeat this card only for **material** issues:

### F-01 — [descriptive title]
- **Category:** observed control deficiency / potential risk / evidence gap / positive control
- **Risk priority:** critical / high / medium / low / not rated, with rationale
- **Established facts:** [citation ID + short verbatim quote]
- **Risk mechanism / consequence:** [clearly labeled inference]
- **Current or proposed controls:** [verified / stated-unverified / planned / unknown / contradicted]
- **What remains unknown / counter-evidence:** [if applicable]
- **Practical recommendation:** [owner, control action and proportionate test]
- **Human review requirement:** [person/role and what must be decided]

## 4. Material information gaps (not automatic findings)
| Information needed | Why it matters | Suggested verification | Priority |
|---|---|---|---|

## 5. Cross-model reconciliation and challenge log
| Issue | Codex preliminary view | Qwen view | DeepSeek view | Primary-evidence ruling and rationale |
|---|---|---|---|---|

- **Supported minority findings retained:** [or none]
- **External assertions rejected or qualified:** [why]
- **Missing/failed external reviewers:** [state actual status]

## 6. Limitations and human review
- This is a decision-support assessment of the supplied proposal, not an independent inspection of source systems, a legal opinion or a compliance certification.
- [Specific case limitations and material unknowns]
- **Human reviewer:** [internal audit / compliance / business owner / IT, as appropriate]
- **Required human actions:** [confirm evidence, approve design/test, review impact, sign off]

## 7. Source list
| ID | Source | Version/section/page | Read status |
|---|---|---|---|
| BG-01 | JL Insurance background | | |
| CEO-01 | Current uploaded brief | | |
